const admin = require('firebase-admin');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');

// Initialize Firebase Admin SDK
const serviceAccount = require('C:\\Users\\xxash\\Documents\\Arduino\\kdcsmsdev-firebase-adminsdk-e79gp-ad11aac4b4.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();

// Set up Serial connection
const port = new SerialPort({
    path: 'COM3', // Change this to the correct port
    baudRate: 9600
});

const parser = port.pipe(new ReadlineParser({ delimiter: '\n' }));

console.log("Waiting for RFID tags...");

parser.on('data', async (data) => {
    const rfidTag = data.trim();
    console.log(`RFID Tag: ${rfidTag}`);

    // Check if the RFID tag exists in Firestore
    const studentsRef = db.collection('Enrolledstudents').where('rfid', '==', rfidTag);
    const snapshot = await studentsRef.get();

    if (snapshot.empty) {
        console.log('No matching student found!');
        return;
    }

    for (const doc of snapshot.docs) {
        const studentData = doc.data();
        const now = new Date();

        // Check if the student is checked in or out and toggle the status
        let status = '';
        if (studentData.checkInStatus === 'checked in') {
            status = 'checked out';
            // Update Firestore with check-out data
            await db.collection('Enrolledstudents').doc(doc.id).update({
                checkInStatus: status,
                lastCheckOut: admin.firestore.FieldValue.serverTimestamp()
            });
            console.log(`${studentData.last_name} checked out at ${now}`);
        } else {
            status = 'checked in';
            // Update Firestore with check-in data
            await db.collection('Enrolledstudents').doc(doc.id).update({
                checkInStatus: status,
                lastCheckIn: admin.firestore.FieldValue.serverTimestamp()
            });
            console.log(`${studentData.last_name} checked in at ${now}`);
        }
    }
});

// Error handling
port.on('error', (err) => {
    console.error('Error: ', err.message);
});
